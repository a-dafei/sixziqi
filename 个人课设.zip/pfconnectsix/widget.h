#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QPushButton>
#include "chessbyperson.h"
#include "fightai.h"
#include "aifight.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    void myslot();     //用于接受信号传过来的数据
    void changeone();   //实现第一个子窗口的显示以及窗口的隐藏
    void changetwo();   //实现第二个子窗口的显示以及窗口的隐藏
    void changethree();  //实现第三个子窗口的显示以及窗口的隐藏
    void dealchessByPerson();   //实现第一个子窗口的隐藏以及窗口的显示
    void dealfightAI();         //实现第二个子窗口的隐藏以及窗口的显示
    void dealAIfight();         //实现第三个子窗口的隐藏以及窗口的显示

protected:
    void paintEvent(QPaintEvent *);   //绘制

private:
    Ui::Widget *ui;

    QPushButton *btn1;
    QPushButton *btn2;
    QPushButton *btn3;
    QPushButton *btn4;

    chessByPerson w1;
    fightAI w2;
    AIfight w3;

};

#endif // WIDGET_H
